"use client"
import { useState } from "react"
import Link from "next/link"
import {
  Wifi,
  Gauge,
  Key,
  CreditCard,
  MessageSquare,
  Clock,
  PhoneCall,
  MessageCircle,
  LogOut,
  User,
  Home,
} from "lucide-react"

export default function DashboardPage() {
  const [speedTestRunning, setSpeedTestRunning] = useState(false)
  const [speedResult, setSpeedResult] = useState<number | null>(null)

  const handleSpeedTest = () => {
    setSpeedTestRunning(true)
    // Simulate speed test
    setTimeout(() => {
      setSpeedResult(Math.floor(Math.random() * 100) + 200)
      setSpeedTestRunning(false)
    }, 3000)
  }

  const handleCancelSubscription = (method: "whatsapp" | "phone") => {
    if (method === "whatsapp") {
      window.open("https://wa.me/5597991461730", "_blank")
    } else {
      window.location.href = "tel:+5597991461730"
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <header className="bg-primary text-white py-6 px-4 shadow-lg">
        <div className="container mx-auto max-w-6xl">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">Central do Assinante</h1>
              <p className="text-white/80 mt-1">Bem-vindo, Usuário</p>
            </div>
            <div className="flex gap-3">
              <Link
                href="/"
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition-colors"
              >
                <Home size={20} />
                <span className="hidden sm:inline">Início</span>
              </Link>
              <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition-colors">
                <LogOut size={20} />
                <span className="hidden sm:inline">Sair</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* User Info Card */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-4 rounded-full">
              <User className="text-primary" size={32} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Informações da Conta</h2>
              <p className="text-gray-600">Plano: Fibra 300 Mega</p>
              <p className="text-sm text-gray-500">Status: Ativo</p>
            </div>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Router Management */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary/10 p-3 rounded-lg">
                <Wifi className="text-primary" size={24} />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Gerenciar Roteador</h2>
            </div>

            <div className="space-y-4">
              {/* Speed Test */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Gauge className="text-accent" size={20} />
                    <span className="font-semibold text-gray-900">Teste de Velocidade</span>
                  </div>
                </div>
                {speedResult && (
                  <div className="mb-3 text-center">
                    <p className="text-3xl font-bold text-primary">{speedResult} Mbps</p>
                    <p className="text-sm text-gray-600">Velocidade de Download</p>
                  </div>
                )}
                <button
                  onClick={handleSpeedTest}
                  disabled={speedTestRunning}
                  className="w-full bg-primary text-white py-2 rounded-lg font-semibold hover:opacity-90 transition-all disabled:opacity-50"
                >
                  {speedTestRunning ? "Testando..." : "Iniciar Teste"}
                </button>
              </div>

              {/* Change WiFi Name */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Wifi className="text-accent" size={20} />
                  <span className="font-semibold text-gray-900">Alterar Nome do WiFi</span>
                </div>
                <input
                  type="text"
                  placeholder="Novo nome da rede"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg mb-2 focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <button className="w-full bg-accent text-white py-2 rounded-lg font-semibold hover:opacity-90 transition-all">
                  Salvar Nome
                </button>
              </div>

              {/* Change Password */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Key className="text-accent" size={20} />
                  <span className="font-semibold text-gray-900">Alterar Senha do WiFi</span>
                </div>
                <input
                  type="password"
                  placeholder="Nova senha"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg mb-2 focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <button className="w-full bg-accent text-white py-2 rounded-lg font-semibold hover:opacity-90 transition-all">
                  Salvar Senha
                </button>
              </div>
            </div>
          </div>

          {/* Support Tickets */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary/10 p-3 rounded-lg">
                <MessageSquare className="text-primary" size={24} />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Chamados</h2>
            </div>

            <div className="space-y-4">
              {/* Open New Ticket */}
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Abrir Novo Chamado</h3>
                <textarea
                  placeholder="Descreva seu problema..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg mb-2 focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                />
                <button className="w-full bg-primary text-white py-2 rounded-lg font-semibold hover:opacity-90 transition-all">
                  Enviar Chamado
                </button>
              </div>

              {/* Ticket History */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="text-accent" size={20} />
                  <h3 className="font-semibold text-gray-900">Histórico de Chamados</h3>
                </div>
                <div className="space-y-2">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-medium text-sm text-gray-900">Problema de conexão</span>
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Resolvido</span>
                    </div>
                    <p className="text-xs text-gray-600">15/04/2025</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-medium text-sm text-gray-900">Lentidão na internet</span>
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">Em andamento</span>
                    </div>
                    <p className="text-xs text-gray-600">10/04/2025</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Payment */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary/10 p-3 rounded-lg">
                <CreditCard className="text-primary" size={24} />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Pagamento</h2>
            </div>

            <div className="space-y-4">
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">Fatura Atual</h3>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600">Vencimento:</span>
                  <span className="font-bold text-gray-900">20/05/2025</span>
                </div>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600">Valor:</span>
                  <span className="text-2xl font-bold text-primary">R$ 99,90</span>
                </div>
                <button className="w-full bg-accent text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-all hover:shadow-lg">
                  Pagar Agora
                </button>
              </div>

              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">Histórico de Pagamentos</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600">Abril 2025</span>
                    <span className="text-green-600 font-medium">Pago</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600">Março 2025</span>
                    <span className="text-green-600 font-medium">Pago</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600">Fevereiro 2025</span>
                    <span className="text-green-600 font-medium">Pago</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Cancel Subscription */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-red-100 p-3 rounded-lg">
                <LogOut className="text-red-600" size={24} />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Cancelar Assinatura</h2>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600 text-sm">
                Sentiremos sua falta! Para cancelar sua assinatura, entre em contato conosco através de um dos canais
                abaixo:
              </p>

              <button
                onClick={() => handleCancelSubscription("whatsapp")}
                className="w-full flex items-center justify-center gap-3 bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600 transition-all hover:shadow-lg"
              >
                <MessageCircle size={20} />
                Cancelar via WhatsApp
              </button>

              <button
                onClick={() => handleCancelSubscription("phone")}
                className="w-full flex items-center justify-center gap-3 bg-primary text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-all hover:shadow-lg"
              >
                <PhoneCall size={20} />
                Cancelar via Ligação
              </button>

              <p className="text-xs text-gray-500 text-center">Horário de atendimento: Segunda a Sexta, 8h às 18h</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
