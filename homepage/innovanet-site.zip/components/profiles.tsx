import { Briefcase, Tv, Gamepad2 } from "lucide-react"

const profiles = [
  {
    icon: Briefcase,
    title: "Home Office",
    subtitle: "Trabalha em casa?",
    backgroundImage: "/placeholder.svg?height=580&width=370",
    iconImage: "/placeholder.svg?height=130&width=370",
  },
  {
    icon: Tv,
    title: "Streaming",
    subtitle: "Assiste filmes e séries?",
    backgroundImage: "/placeholder.svg?height=580&width=370",
    iconImage: "/placeholder.svg?height=130&width=370",
  },
  {
    icon: Gamepad2,
    title: "Gamer",
    subtitle: "Joga Bastante?",
    backgroundImage: "/placeholder.svg?height=580&width=370",
    iconImage: "/placeholder.svg?height=130&width=370",
  },
]

export default function Profiles() {
  return (
    <section className="py-20 bg-[#fafafa]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Aqui você tem <strong>muito mais</strong>
          </h2>
          <p className="text-xl text-gray-600">Qual seu perfil de velocidade?</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {profiles.map((profile) => (
            <a
              key={profile.title}
              href="#planos"
              className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
            >
              <div className="aspect-[370/580] relative overflow-hidden">
                <img
                  src={profile.backgroundImage || "/placeholder.svg"}
                  alt={profile.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-8 text-white text-center">
                <div className="mb-4">
                  <img
                    src={profile.iconImage || "/placeholder.svg"}
                    alt={`${profile.title} icon`}
                    className="mx-auto h-16 w-auto opacity-90"
                  />
                </div>

                <h4 className="text-2xl font-bold mb-2">{profile.title}</h4>
                <h5 className="text-lg mb-6 opacity-90">{profile.subtitle}</h5>

                <div className="inline-block">
                  <span className="relative inline-block bg-accent hover:bg-accent/90 px-8 py-3 rounded-lg font-semibold transition-all duration-300 group-hover:scale-105">
                    <span className="relative z-10">Veja os planos</span>
                  </span>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
